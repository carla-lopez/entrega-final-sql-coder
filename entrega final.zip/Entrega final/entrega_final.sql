use entrega_final;

create table if not exists usuario(
id_usuario int primary key,
nombre varchar (20) not null,
apellido varchar (20) not null,
direccion varchar(50) not null,
mail varchar(50) not null,
tel varchar(25) not null,
dni varchar(15) not null
);

create table if not exists historial(
id_historial int primary key,
fecha date not null,
enf_padecido varchar(150),
observaciones varchar(250)
);


create table if not exists farmacia(
id_farmacia int primary key,
farmacos varchar(150),
prospecto varchar(400),
precio float not null,
stock varchar (20) not null default 'disponible'
);

create table if not exists turno(
id_turno int primary key,
fecha date not null,
hora time not null,
motivo_consulta varchar(250) not null
);


create table if not exists mascota(
id_mascota int primary key,
idusuario int not null,
idhistorial int not null,
idfarmacia int not null,
idturno int not null,
nombre varchar(50) not null,
tipo varchar(80) not null,
raza varchar(80) not null,
fecha_nac date not null,
peso varchar (5) not null,
constraint fk_usuario foreign key(idusuario) references usuario(id_usuario),
constraint fk_historial foreign key(idhistorial) references historial(id_historial),
constraint fk_farmacia foreign key(idfarmacia) references farmacia(id_farmacia),
constraint fk_turno foreign key(idturno) references turno(id_turno)
);


show tables;

select * from mascota;
drop view v_usuario;

create VIEW V_Usuario as SELECT nombre,apellido,dni from usuario;

drop view v_farmacia;
create VIEW V_Farmacia as SELECT farmacos,prospecto from farmacia; 

select * from V_Usuario;

select * from V_Farmacia;

drop view v_cita;
create VIEW V_Cita as SELECT usuario.id_usuario,usuario.nombre,usuario.apellido,usuario.dni,turno.id_turno,turno.fecha,turno.hora,turno.motivo_consulta from usuario,turno WHERE usuario.id_usuario=turno.id_turno;

select * from V_Cita;

drop view v_receta;
create VIEW V_Receta as SELECT farmacia.id_farmacia,farmacia.farmacos,historial.id_historial,historial.observaciones from farmacia,historial WHERE farmacia.id_farmacia=historial.id_historial;

select * from V_Receta;

drop view v_compra;
create VIEW V_Compra as SELECT usuario.id_usuario,usuario.dni,farmacia.id_farmacia,farmacia.farmacos from usuario,farmacia where usuario.id_usuario=farmacia.id_farmacia;

select * from V_Compra;

DELIMITER //

drop procedure insertar;
create procedure insertar (paranom varchar(50), paraape varchar(50))  
begin
  insert into usuario(nombre,apellido) values (paranom,paraape); 
  end //
  
  delimiter ;
  
  drop procedure eliminar;
  DELIMITER //
  
  create procedure eliminar (in id int)
  begin
  delete from usuario where id_usuario=id;
  end//
  
  delimiter ;
  
  drop procedure obtenerFarmacosPorEstado;
  DELIMITER //
  
  create procedure obtenerFarmacosPorEstado (IN nombre_estado varchar(255))
  begin
  select *
  from farmacia
  where stock = nombre_estado;
  end //
  
  delimiter ;
  
  call obtenerFarmacosPorEstado('disponible');
  




DELIMITER $$

create function tipoAnimal (peso varchar)
returns varchar(20)
deterministic
begin
declare tipoAnimal varchar(20);

if peso >60 then
set tipoAnimal = 'Grande';
elseif (peso <=60 and peso >=20)then
set tipoAnimal = 'Mediano';
elseif peso <=20 then
set tipoAnimal = 'Pequeño';
end if;

return(tipoAnimal);
end 

delimiter ;
  
 DELIMITER //
 CREATE function 'tipo farmaco'(precio float int)
 return varchar(10)
 deterministic
 begin
 declare resultado varchar(10);
 
 if precio > 8000 then
 return 'ALTO';
 else
 return 'BAJO';
 end if
 
 end;
 
 delimiter ;
 
 drop table logs;
 create table logs(
id int primary key,
tabla varchar(50),
accion varchar (200),
usuario varchar(50),
fecha date
);
 
 drop trigger farmacia_after_insert;
 DELIMITER //
 CREATE TRIGGER `farmacia_AFTER_INSERT` AFTER INSERT ON `farmacia` FOR EACH ROW BEGIN 
      insert into logs(id,tabla,accion,usuario,fecha) 
      values(null,'farmacia',concat('Ingreso de nuevo farmaco; ',NEW.id_farmacia), USER(), CURDATE());
END //

delimiter ;

DELIMITER //
create trigger 'farmacia_AFTER_DELETE' AFTER DELETE ON 'farmacia' FOR EACH ROW BEGIN
insert into logs(id,tabla,accion,usuario,fecha)
values(null,'farmacia',concat('Eliminacion de farmaco: ',old.id:farmacia),user(), curdate());
END $$

delimiter ;

DELIMITER //

create function carga_sistema (nombre varchar (20), apellido varchar (20),mail varchar(50))returns varchar (150)
deterministic
begin
declare nombre_completo varchar(100);
set nombre_completo = concat (nombre,'',apellido);
if mail is not null then
return concat ('Usuario activo',nombre_completo);
else
return 'Aun sin registrar';
end if;
end//

delimiter ;

select fecha as 'fecha venta', date_format(fecha, '%D %M %Y') as 'Nuevo formato' from turno;

select max(precio) as 'precio maximo' from farmacia;

select min(precio) as 'precio minimo' from farmacia;

